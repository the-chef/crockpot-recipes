##Setup InsightVM account and copy ssh key

userdel -r insightvm
useradd -d /home/insightvm -m insightvm
chage -M -1 insightvm
passwd -l insightvm
mkdir /home/insightvm/.ssh
cp authorized_keys /home/insightvm/.ssh/authorized_keys
chown -R insightvm:insightvm  /home/insightvm/.ssh/ 
chmod 0600 /home/insightvm/.ssh/authorized_keys 
chmod 0700 /home/insightvm/.ssh/

##Modify sudoers file
echo
echo "Add these entries to the sudoer file"
echo
echo "====================================="
echo "User_Alias INSIGHTVM_USER=insightvm"
echo "INSIGHTVM_USER ALL=(ALL)NOPASSWD:ALL"
echo
